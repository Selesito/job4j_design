package ru.job4j.refactor;

public class ArgZip {
    private String[] args;

    public ArgZip(String[] args) {
        this.args = args;
    }

    public boolean isValid() {
        if (directory() != null &&
        exclude() != null && output() != null) {
            return true;
        }
        return false;
    }

    private String directory() {
        String[] rsl = args[0].trim().split("=");
        String directory = rsl[1];
        if (!directory.isEmpty()) {
            return directory;
        }
        return null;
    }

    private String exclude() {
        String[] rsl = args[1].trim().split("=");
        String exclude = rsl[1];
        if (!exclude.isEmpty()) {
            return exclude;
        }
        return null;
    }

    private String output() {
        String[] rsl = args[2].trim().split("=");
        String output = rsl[1];
        if (!output.isEmpty()) {
            return output;
        }
        return null;
    }
}
