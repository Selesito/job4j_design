package ru.job4j.refactor;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Analizy {

    public void unavailable(String source, String target) {
        List<String> rsl = new ArrayList<>();
        try (BufferedReader in = new BufferedReader(new FileReader(source))) {
            boolean flag = false;
            String result = null;
            for (String line = in.readLine(); line != null; line = in.readLine()) {
                if (!flag && line.contains("400") || line.contains("500")) {
                    String[] tmp = line.trim().split(" ");
                    result = tmp[1] + " - ";
                    flag = true;
                }
                if (flag && line.contains("200") || line.contains("300")) {
                    String[] tmp = line.trim().split(" ");
                    result += tmp[1];
                    rsl.add(result);
                    flag = false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        write(rsl, target);
    }

    public void write(List<String> tmp, String target) {
        try (PrintWriter out = new PrintWriter(
                new BufferedOutputStream(
                        new FileOutputStream(target)
                ))) {
            for (String rsl : tmp) {
                out.println(rsl);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String sour = "sourse.txt";
        String targ = "target.txt";
        new Analizy().unavailable(sour, targ);
    }
}
