package ru.job4j.refactor;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import static java.nio.file.FileVisitResult.CONTINUE;

public class Search {

    public static List<Path> search(Path root, Predicate<Path> condition) throws IOException {
        SearchFiles searcher = new SearchFiles(condition);
        Files.walkFileTree(root, searcher);
        return searcher.getPatch();
    }

    private static class SearchFiles implements FileVisitor<Path> {
        private Predicate<Path> predicate;
        private List<Path> patch;

        public SearchFiles(Predicate<Path> predicate) {
            this.predicate = predicate;
            this.patch = new ArrayList<>();
        }

        public List<Path> getPatch() {
            return patch;
        }

        @Override
        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
            return CONTINUE;
        }

        @Override
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
            if (predicate.test(file)) {
                patch.add(file);
            }
            return CONTINUE;
        }

        @Override
        public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
            return CONTINUE;
        }

        @Override
        public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
            return CONTINUE;
        }
    }

    public static void main(String[] args) throws IOException {
        Path start = Paths.get(args[0]);
        if (args.length < 2) {
            throw new IllegalArgumentException();
        }
        search(start, p -> p.toFile().getName().endsWith(args[1])).forEach(System.out::println);
    }
}
