package ru.job4j.refactor;

import org.junit.Test;
import ru.job4j.io.Config;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

public class ConfigTest {

    @Test
    public void whenPairWithoutComment() {
        String path = "pair_without_comment.txt";
        ru.job4j.io.Config config = new ru.job4j.io.Config(path);
        config.load();
        assertThat(
                config.value("name"),
                is("Petr Arsentev")
        );
    }

    @Test(expected = UnsupportedOperationException.class)
    public void whenKeyValue() {
        String path = "pair_without_comment.txt";
        ru.job4j.io.Config config = new Config(path);
        config.load();
        assertThat(
                config.value("names"),
                is("Petr Arsentev")
        );
    }
}